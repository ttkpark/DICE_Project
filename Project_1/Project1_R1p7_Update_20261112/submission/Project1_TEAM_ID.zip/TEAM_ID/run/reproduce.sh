#!/usr/bin/env bash
# EE362 Project 1 제출본 재현 (DICE 수업 서버, R1.7).
# 사용: bash run/reproduce.sh <R1.4 ZIP> <R1.7 ZIP> [작업 폴더]
#   예) bash run/reproduce.sh ~/Project1_INT8_Release1p4_20261103.zip ~/Project1_R1p7_Update_20261112.zip ~/p1_repro
# 하는 일: 공식 R1.4 패키지를 새로 풀고 R1.7 누적 업데이트(R1.5·R1.6 포함)를 적용한 뒤, 이 제출본의
#          RTL·SDC·프로그램·도구를 넣고 공식 flow(check_release -> run_sim.sh -> run_ppa.sh)를 처음부터 돈다.
set -euo pipefail
SUB="$(cd -- "$(dirname -- "$0")/.." && pwd)"
R14="$(readlink -f "$1")"; R17="$(readlink -f "$2")"; WORK="${3:-$HOME/p1_repro}"
mkdir -p "$WORK" && cd "$WORK"
rm -rf Project1_INT8_R1p4_20261103
unzip -q "$R14"
cd Project1_INT8_R1p4_20261103
unzip -o -q "$R17"
cp "$SUB"/rtl/TOP.v "$SUB"/rtl/CORE.v "$SUB"/rtl/CONTROLLER.v rtl/
cp "$SUB"/synth/common.sdc "$SUB"/synth/rtl.f synth/          # 주기 1.62 ns, CPU RTL 3개
mkdir -p programs && cp "$SUB"/asm/int8_fastv2.s "$SUB"/asm/int8_fastv2.hex "$SUB"/asm/int8_fastv2.lst programs/
cp "$SUB"/tools/run_flow.py "$SUB"/tools/check_release.py "$SUB"/tools/trim_vcd.py tools/   # 측정에 쓴 판
/usr/bin/python3.12 tools/check_release.py
bash run_sim.sh --program programs/int8_fastv2.hex
bash run_ppa.sh
ls -lh results/TOP_mapped.ddc
echo "비교: $SUB/results/ppa_summary.json  <->  $PWD/results/ppa_summary.json"
