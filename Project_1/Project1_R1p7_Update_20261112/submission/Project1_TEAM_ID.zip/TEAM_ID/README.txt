EE362 Project 1 (INT8 선형계층) 제출본 - 박기호, 김대현

[최종 설계]
  CPU      : 5단 파이프라인 RV32I, BEQ/JAL 을 EX 단에서 판정 (rtl/CORE.v)
  프로그램 : asm/int8_fastv2.s (193 word -> IMEM 256 구간)
  명령어   : 기본 8개(ADD SUB AND ADDI LW SW BEQ JAL)만 사용. 선택 RV32I 명령 없음 -> 단독 기능 시험 대상 없음
  선언 주기: 1.62 ns (617.28 MHz), synth/common.sdc 의 -period 숫자만 변경

[측정 결과] 공개 16 case, R1.4 공통 flow + R1.7 업데이트(R1.6 계층 DDC 합성 Tcl), 2026-11-14 DICE 서버
  기능     : 16/16 PASS (logs/<case>.log)
  timing   : PASS, setup +0.00261915 ns, hold +0.114771 ns (reports/setup.rpt, hold.rpt, results/ppa_status.json)
  평균 cycle 630.25, case 당 load 50 / store 5 (results/simulation_manifest.json)
  T = 1.021005 us
  A = CPU 22322.99 + IMEM 27352.30 + DMEM 50667.68 = 100342.97 um2 (reports/cpu_area.rpt)
  P = CPU 8.8303 + 메모리 동적 5.0197 + 메모리 정적 1.5604 = 15.4104 mW (reports/<case>/power.rpt)
  요약     : results/ppa_summary.json (fingerprint e486b618bea44bc65e97b57f4e8668ad8fd524941ae36f8605b912e3b3ea2260)
  DDC      : results/TOP_mapped.ddc (R1.6 부터 필수, 같은 실행에서 생성). 계층은 reports/cpu_hierarchy.rpt (TOP > CORE > CONTROLLER)

[폴더]
  rtl/           TOP.v CORE.v CONTROLLER.v (synth/rtl.f 의 합성 목록과 같음)
  asm/           int8_fastv2.s .hex .lst
  synth/         common.sdc (period 1.62), rtl.f
  tools/         측정에 쓴 run_flow.py, check_release.py, trim_vcd.py
                 (공식본에서 Python 3.6 호환으로 is_relative_to, write_text(newline=) 두 곳을 바꾼 판. 3.12 에서도 같게 동작)
  run/           reproduce.sh : 공식 R1.4 ZIP + R1.7 ZIP 에서 처음부터 재현
  results/       ppa_summary.json, ppa_status.json, simulation_manifest.json, TOP_mapped.ddc, TOP_mapped.v, TOP_normal_mode.sdc
  reports/       setup, hold, cpu_area, cpu_hierarchy, constraints, check_*, case 별 power.rpt·annotation.rpt
  logs/          compile.log, case 별 기능 로그 16개, vcd2saif 로그, dc_ppa.log
  presentation/  project1.pptx (발표 슬라이드), project1.pdf

[재현]
  bash run/reproduce.sh <Project1_INT8_Release1p4_20261103.zip> <Project1_R1p7_Update_20261112.zip> [작업 폴더]
  내부 명령: python3.12 tools/check_release.py
             bash run_sim.sh --program programs/int8_fastv2.hex
             bash run_ppa.sh
  공식 스크립트 없이 vcs_queue / simv / vcd2saif / dc_shell_queue 로 단계별 재현하는 순서는 발표 슬라이드 부록 E.

[주의]
  공개 16 case 연습 결과이며 공식 성적은 숨김 case 를 포함한 24 case 로 따로 산출된다.
  전력은 배치·배선 전 추정, 메모리 전력은 계약서의 수업용 산식이다.
  logs/dc_ppa.log 의 error "P1: ..." 줄은 Tcl 스크립트 본문이 그대로 찍힌 것이며 실행은 P1_PPA_COMPLETE 로 끝났다.
